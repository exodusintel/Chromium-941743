Chrome 73.0.3683.86 stable exploit for chromium issue 941743, tested on Windows 10 x64. 

* start chrome with the --no-sandbox argument
* navigate to exp.html and start the exploit by pressing the button